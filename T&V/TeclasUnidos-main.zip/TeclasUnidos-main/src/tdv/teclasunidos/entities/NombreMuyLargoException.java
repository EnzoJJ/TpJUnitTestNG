package tdv.teclasunidos.entities;

public class NombreMuyLargoException extends Exception {

}
