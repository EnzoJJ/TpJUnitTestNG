package tdv.teclasunidos.entities;

public class EdadInvalidaException extends Exception {

}
